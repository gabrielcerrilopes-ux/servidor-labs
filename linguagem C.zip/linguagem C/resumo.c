/*
%d	int
%f	float
%lf	double no scanf
%c	char
%s	string
%p	endereço de ponteiro
*/

/*
else if
Utilizado quando existem várias condições.

int nota = 7;

if (nota >= 9) {
    printf("Excelente");
} else if (nota >= 6) {
    printf("Aprovado");
} else {
    printf("Reprovado");
}
*/

/*
switch case
Utilizado quando queremos comparar uma variável com diferentes valores específicos.

int opcao = 2;

switch (opcao) {

    case 1:
        printf("Cadastrar");
        break;

    case 2:
        printf("Consultar");
        break;

    case 3:
        printf("Sair");
        break;

    default:
        printf("Opcao invalida");
}

case: representa uma opção.
break: encerra o switch.
default: executa quando nenhuma opção corresponde.
*/

/*
Operadores de comparação
Operador	Significado
==	Igual
!=	Diferente
>	Maior
<	Menor
>=	Maior ou igual
<=	Menor ou igual

Operadores lógicos
Operador	Significado
&&	E – ambas as condições precisam ser verdadeiras
\|\|	OU – pelo menos uma precisa ser verdadeira
!	NÃO – inverte a condição
*/

/*
while
Repete enquanto a condição for verdadeira.

int i = 1;

while (i <= 5) {

    printf("%d\n", i);

    i++;
}

O i++ aumenta o valor de i em 1.
*/

/*
for
Ideal quando sabemos quantas vezes queremos repetir.

for (int i = 1; i <= 5; i++) {

    printf("%d\n", i);

}
for (inicio; condicao; incremento)

Inicialização: onde começa.
Condição: até quando repete.
Incremento: como a variável muda.
*/

/*
do while
Executa o código pelo menos uma vez, mesmo que a condição seja falsa.

int numero = 1;

do {

    printf("%d\n", numero);

    numero++;

} while (numero <= 5);
*/

/*
break e continue
break: interrompe completamente a repetição.

for (int i = 1; i <= 10; i++) {

    if (i == 5) {
        break;
    }

    printf("%d\n", i);
}

1,2,3,4

continue: pula somente a repetição atual.

for (int i = 1; i <= 5; i++) {

    if (i == 3) {
        continue;
    }

    printf("%d\n", i);
}
    1,2,4,5
*/

/*
Recursão
Recursão acontece quando uma função chama ela mesma.

Exemplo: fatorial de 5.
int fatorial(int n) {

    if (n == 1) {
        return 1;
    }

    return n * fatorial(n - 1);
}
    printf("%d", fatorial(5));
*/

/*
Vetores
Um vetor armazena vários elementos em uma única variável.
int numeros[5] = {10, 20, 30, 40, 50};

Para acessar um elemento:
printf("%d", numeros[0]);
10

Percorrendo um vetor
int numeros[5] = {10, 20, 30, 40, 50};

for (int i = 0; i < 5; i++) {

    printf("%d\n", numeros[i]);

}

recebendo valores do usuário
int numeros[5];

for (int i = 0; i < 5; i++) {

    scanf("%d", &numeros[i]);

}

somar elementos:
int numeros[5] = {2, 4, 6, 8, 10};
int soma = 0;

for (int i = 0; i < 5; i++) {

    soma += numeros[i];

}

printf("Soma: %d", soma);
*/

/*
Matrizes
Uma matriz é um vetor de duas dimensões, ou seja, uma tabela com linhas e colunas.
int matriz[2][3] = {
    {1, 2, 3},
    {4, 5, 6}
};

Percorrer uma matriz
int matriz[2][3] = {
    {1, 2, 3},
    {4, 5, 6}
};

for (int i = 0; i < 2; i++) {

    for (int j = 0; j < 3; j++) {

        printf("%d ", matriz[i][j]);

    }

    printf("\n");
}
*/
/*
Funções
Funções são blocos de código que realizam tarefas específicas. 
Permitem reutilizar códigos sem precisar escrevê-los novamente.

int somar(int a, int b) {

    return a + b;

}

int main() {

    int resultado = somar(10, 5);

    printf("%d", resultado);

    return 0;
}
Função void
Uma função void não retorna nenhum valor.

Protótipo de função
É a declaração da função antes de sua utilização.

#include <stdio.h>

int somar(int a, int b);

int main() {

    printf("%d", somar(2, 3));

    return 0;
}

int somar(int a, int b) {

    return a + b;

}
*/

/*
Strings
Strings são sequências de caracteres utilizadas para armazenar textos.

Em C, uma string é armazenada em um vetor de caracteres e termina com o caractere especial \0

char nome[20] = "Gabriel";

recebendo uma string
char nome[50];

printf("Digite seu nome: ");
scanf("%49s", nome);

Para ler uma frase inteira:
char nome[50];
fgets(nome, 50, stdin);

biblioteca string.h
strlen()	Calcula o tamanho da string
char nome[] = "Gabriel";
printf("%d", (int)strlen(nome));

strcpy()	Copia uma string
char nome[20];
strcpy(nome, "Gabriel");

strcat()	Junta duas strings
char nome[30] = "Gabriel";
strcat(nome, " Lopes");
printf("%s", nome);

strcmp()	Compara duas strings
char senha1[] = "123";
char senha2[] = "123";

if (strcmp(senha1, senha2) == 0) {

    printf("Senhas iguais");

}
*/

/*
Ponteiros
Um ponteiro é uma variável que armazena o endereço de memória de outra variável.

int numero = 10;

int *p;

p = &numero;


#include <stdio.h>

int main() {

    int numero = 20;

    int *p = &numero;

    printf("%d\n", numero);

    printf("%p\n", (void*)p);

    printf("%d\n", *p);

    return 0;
}
Alterando um valor através do ponteiro

int numero = 10;

int *p = &numero;

*p = 50;

printf("%d", numero);

Ponteiros em funções
São utilizados quando queremos alterar uma variável original dentro de uma função.

void alterar(int *p) {

    *p = 100;

}

int main() {

    int numero = 10;

    alterar(&numero);

    printf("%d", numero);

    return 0;
}
*/

/*
Arquivos
Permitem salvar informações permanentemente no computador.

FILE *arquivo;

arquivo = fopen("dados.txt", "w");

Modo	Significado
"r"	Ler arquivo existente
"w"	Escrever, apagando o conteúdo anterior
"a"	Adicionar ao final
"r+"	Ler e escrever
"w+"	Ler e escrever, apagando o conteúdo anterior
"a+"	Ler e adicionar ao final

#include <stdio.h>

int main() {

    FILE *arquivo;

    arquivo = fopen("dados.txt", "w");

    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo");
        return 1;
    }

    fprintf(arquivo, "Ola Gabriel");

    fclose(arquivo);

    return 0;
}

#include <stdio.h>

int main() {

    FILE *arquivo;
    char texto[100];

    arquivo = fopen("dados.txt", "r");

    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo");
        return 1;
    }

    fgets(texto, 100, arquivo);

    printf("%s", texto);

    fclose(arquivo);

    return 0;
}

Função	Utilidade
fopen()	Abre arquivo
fclose()	Fecha arquivo
fprintf()	Escreve dados formatados
fscanf()	Lê dados formatados
fgets()	Lê uma linha
fputs()	Escreve uma string
fgetc()	Lê um caractere
fputc()	Escreve um caractere

Atenção: sempre verifique se fopen() retornou NULL e feche os arquivos com fclose().
*/

/*
Gerenciamento de memória
É o processo de reservar, utilizar e liberar memória durante a execução do programa.

Em C, podemos reservar memória dinamicamente utilizando funções da biblioteca stdlib.h.
#include <stdlib.h>

malloc()
Reserva uma quantidade de memória sem inicializar os valores.
int *p;

p = malloc(5 * sizeof(int));


Nesse caso, reservamos espaço para 5 números inteiros.
9.2. calloc()
Semelhante ao malloc, mas inicializa os espaços reservados com zero.
int *p;

p = calloc(5, sizeof(int));


9.3. realloc()
Altera o tamanho de uma memória que já foi reservada dinamicamente.
int *p;

p = malloc(5 * sizeof(int));

p = realloc(p, 10 * sizeof(int));


Agora temos espaço para 10 inteiros.

Na prática, é melhor utilizar um ponteiro auxiliar para evitar perder o endereço original caso a realocação falhe.
9.4. free()
Libera a memória reservada dinamicamente.
free(p);

p = NULL;


Comparação
Função	O que faz
malloc()	Reserva memória
calloc()	Reserva memória inicializada com zero
realloc()	Redimensiona a memória
free()	Libera a memória
*/

/*
Structs (estruturas)
Uma struct permite agrupar diferentes tipos de variáveis dentro de uma única estrutura.

Por exemplo, um cadastro de aluno possui nome, idade e nota.

#include <stdio.h>

struct Aluno {

    char nome[50];
    int idade;
    float nota;

};

int main() {

    struct Aluno aluno1;

    aluno1.idade = 18;
    aluno1.nota = 9.5;

    printf("%d", aluno1.idade);

    return 0;
}
    onteiros para structs
Quando temos um ponteiro para uma struct, podemos utilizar -> para acessar seus campos.
struct Aluno {
    int idade;
};

int main() {

    struct Aluno aluno;

    struct Aluno *p = &aluno;

    p->idade = 18;

    printf("%d", aluno.idade);

    return 0;
}

Operador	Utilização
.	Acessar campo de uma variável struct
->	Acessar campo através de um ponteiro para struct
*/

/*
ypedef e enum
São recursos que ajudam a organizar e facilitar a leitura do código.
11.1. typedef
Permite criar um nome alternativo para um tipo de dado.

typedef struct {

    int idade;

} Aluno;

enum
Permite criar um conjunto de constantes inteiras com nomes.

Exemplo:
enum Dia {

    SEGUNDA,
    TERCA,
    QUARTA,
    QUINTA,
    SEXTA

};

typedef enum {

    APROVADO,
    REPROVADO,
    RECUPERACAO

} Situacao;
 Situacao aluno = APROVADO;
*/

/*
Ponteiros de funções
É um ponteiro que armazena o endereço de uma função.

Isso permite escolher qual função será executada através de um ponteiro.

#include <stdio.h>

int somar(int a, int b) {

    return a + b;

}

int main() {

    int (*p)(int, int);

    p = somar;

    printf("%d", p(10, 5));

    return 0;
}
*/

/*
1. stdio.h – Entrada e saída de dados (printf, scanf) e manipulação de arquivos (fopen, fprintf, fscanf, fclose).

2. stdlib.h – Gerenciamento de memória (malloc, calloc, realloc, free) e uso de exit.

3. string.h – Manipulação de strings (strlen, strcpy, strcat, strcmp).
*/