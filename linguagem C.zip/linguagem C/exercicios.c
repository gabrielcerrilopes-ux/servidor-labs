/*1-Escreva um programa que calcula a média aritmética de 5
números digitados pelo usuário. Utilize contadores e
acumuladores.*/

/*#include <stdio.h>

int main() {
    int contador = 0;
    float numero, soma = 0, media;

    while(contador<5){
        printf("Digite seu número:");
        scanf("%f", &numero);
        soma +=numero;
        contador++;
    }
    media =soma/contador;
    printf("A média é: %.2f", media);
    return 0;
}*/
/*2-Faca um programa que imprima os números de 1 a 50 de 1 em 1 e
de 52 a 100 de 2 em 2.*/

/*#include <stdio.h>

int main(){
    int i;
    for(i=1;i<=50;i++){
        printf("%d\n",i);
    }
    for(i=52;i<=100;i+=2){
        printf("%d\n",i);
    }
    return 0;
}*/

/*3-Faca um programa que leia 6 números inteiro positivos do usuário
exiba o maior o numero lido.*/

/*#include <stdio.h>

int main(){
    int i,numero,maior=0;
    for(i=0;i<6;i++){
        printf("digite um numero: ");
        scanf("%d",&numero);
        if(numero>maior)
            maior = numero;
    }
    printf("O maior número lido foi: %d", maior);
    return 0;
}*/
/*4. Escreva um programa que leia números digitados pelo usuário.
O programa deve ler os números ate que o 0 (zero) seja
digitado.
Quando o 0 for digitado, o programa deve exibir:
⋆ a quantidade de números que foram digitados;
⋆ a somatória destes números;
⋆ e a media aritmética.*/

/*#include <stdio.h>

int main() {

    int numero, quantidade = 0, soma = 0;
    float media;

    printf("Digite um numero: ");
    scanf("%d", &numero);

    while(numero != 0) {

        quantidade++;
        soma += numero;

        printf("Digite um numero: ");
        scanf("%d", &numero);
    }

    if(quantidade > 0) {
        media = (float)soma / quantidade;
    } else {
        media = 0;
    }

    printf("\nQuantidade: %d", quantidade);
    printf("\nSoma: %d", soma);
    printf("\nMedia: %.2f\n", media);

    return 0;
}*/

/*Escreva uma função recursiva para cálculo de potência:
pot(base, expoente) que, quando invocada, retorna base elevado ao expoente*/

/*#include <stdio.h>

int pot(int base,int expoente){
    if(expoente==0){;
    return 1;
    }
    return base*pot(base,expoente-1);
}

int main(){
    int base,expoente;
    printf("digite a base:");
    scanf("%d",&base);
    printf("digite o expoente:");
    scanf("%d",&expoente);
    printf("O resultado é: %d", pot(base, expoente));
    return 0;
}*/

/*Implemente uma função float potencia(float x, int n) que devolva o
valor de x elevado a n.*/

/*#include <stdio.h>

float potencia(float x,int n){
    if(n==0){
        return 1;
    }
    return x*potencia(x,n-1);
}

int main(){
    float x;
    int n;
    printf("digite o valor de x:");
    scanf("%f",&x);
    printf("digite o valor de n:");
    scanf("%d",&n);
    printf("o resultado é: %.2f",potencia(x,n));
    return 0;
}*/

/*Crie uma função void modifica (int *x), que deve mudar o valor
passado como parâmetro para o próximo inteiro ímpar. Ex: para a
variável inteira a, a=5; modifica(&a); fará com que o valor de a se
torne 7; a=2; modifica(&a); fará com que o valor de a se torne 3.*/

/*void modifica(int*x){
    if(*x%2==0){
        *x=*x+1;
    }
    else{
        *x=*x+2;
    }
}

int main(){
    int a;
    printf("digite um numero:");
    scanf("%d",&a);
    modifica(&a);
    printf("O próximo inteiro ímpar é: %d",a);
    return 0;
}*/

/*Crie uma função para calcular e retornar o peso de uma pessoa nos
outros planetas do Sistema Solar. A função deve ter dois parâmetros: o
planeta desejado e o peso em Kg da pessoa na Terra. O programa
principal deve receber o peso da pessoa na Terra (em Kg) e o planeta
desejado.
Relação de pesos: 1 Kg na Terra equivale a: 0.37 Kg em Mercúrio; 0.88 Kg
em Vênus; 0.38 Kg em Marte; 2.64 Kg em Júpiter; 1.15 Kg em Saturno; 1.17
Kg em Urano; e 1.18 Kg em Netuno.*/

/*#include <stdio.h>

float peso_planeta(int planeta, float peso_terra){
    switch(planeta){
        case 1:
            return peso_terra*0.37;
        case 2:
            return peso_terra*0.88;
        case 3:
            return peso_terra*0.38;
        case 4:
            return peso_terra*2.64;
        case 5:
            return peso_terra*1.15;
        case 6:
            return peso_terra*1.17;
        case 7:
            return peso_terra*1.18;
        default:
            printf("Planeta inválido.\n");
            break;
    }
}

int main(){
    float peso_terra;
    int planeta;
    printf("Digite seu peso na Terra (em Kg): ");
    scanf("%f",&peso_terra);
    printf("Escolha o planeta desejado:\n");
    scanf("%d",&planeta);
    float peso = peso_planeta(planeta, peso_terra);
    if(peso > 0){
        printf("Seu peso no planeta escolhido é: %.2f Kg\n", peso);
    }
    return 0;
}*/

/*Escreva um programa que recebe quatro strings que representam números inteiros, converte as string
sem inteiros, soma os valores e imprime o total dos quatro
valores.
*/

/*#include <stdio.h>
#include <stdlib.h>

int main(){
    char str1[10], str2[10], str3[10], str4[10];
    int num1,num2,num3,num4;

    printf("Digite o primeiro número: ");
    scanf("%s", str1);
    printf("Digite o segundo número: ");
    scanf("%s", str2);
    printf("Digite o terceiro número: ");
    scanf("%s", str3);
    printf("Digite o quarto número: ");
    scanf("%s", str4);
    num1 = atoi(str1);
    num2 = atoi(str2);
    num3 = atoi(str3);
    num4 = atoi(str4);
    int soma= num1 + num2 + num3 + num4;
    printf("A soma dos quatro números é: %d\n", soma);
    return 0;

}*/

/*Escreva um programa que declare um inteiro, um real, um char, e
ponteiros para inteiro, real, e char. Associe as variáveis aos
ponteiros (use &). Modifique os valores de cada variável usando
os ponteiros. Imprima os valores das variáveis antes e após as
modificações.*/

/*#include <stdio.h>
#include <stdlib.h>

int main() {
    int inteiro = 10;
    float real = 5.5;
    char caractere = 'A';

    int *p_inteiro = &inteiro;
    float *p_real = &real;
    char *p_caractere = &caractere;

    printf("Valores antes das modificacoes:\n");

    printf("Inteiro: %d\n", inteiro);
    printf("Real: %.2f\n", real);
    printf("Caractere: %c\n", caractere);

    *p_inteiro = 20;
    *p_real = 8.5;
    *p_caractere = 'B';

    printf("\nValores depois das modificacoes:\n");

    printf("Inteiro: %d\n", inteiro);
    printf("Real: %.2f\n", real);
    printf("Caractere: %c\n", caractere);

    return 0;
}*/

/*Faça um programa para somar dois números reais utilizando
ponteiros.
*/

/*#include <stdio.h>
#include <stdlib.h>

int main() {
    int num1,num2,soma;
    int *p_num1 = &num1;
    int *p_num2 = &num2;
    int *p_soma = &soma;

    printf("Digite o primeiro número: ");
    scanf("%d", p_num1);
    printf("Digite o segundo número: ");
    scanf("%d", p_num2);

    soma = *p_num1 + *p_num2;
    printf("A soma dos dois números é: %d\n", soma);
    return 0;
}
*/

/*Escreva um programa que contenha duas variáveis inteiras. Leia o
valor dessas variáveis pelo teclado. Em seguida, compare seus
endereços e exiba o conteúdo do maior endereço.*/

/*#include <stdio.h>

int main(){
    int var1,var2;
    printf("Digite o valor da primeira variável: ");
    scanf("%d", &var1);
    printf("Digite o valor da segunda variável: ");
    scanf("%d", &var2);

    if(&var1 > &var2){
        printf("O conteúdo do maior endereço é: %d\n", var1);
    }
    else{
        printf("O conteúdo do maior endereço é: %d\n", var2);
    }
    return 0;
}*/

/*Faça um programa que cria e grava números inteiros de 0 a 999,
pares e ímpares em arquivos separados. Números pares no
arquivo com nome pares.txt e os ímpares no arquivo com nome
impares.txt.*/

/*#include <stdio.h>
#include <stdlib.h>

int main(){
    FILE *pares, *impares;
    pares = fopen("pares.txt", "w");
    impares = fopen("impares.txt", "w");
    if(pares == NULL || impares == NULL) {
        printf("Erro ao abrir os arquivos.\n");
        return 1;
    }
    for(int i=0;i<1000;i++){
        if(i%2==0){
            fprintf(pares, "%d\n", i);
        }
        else{
            fprintf(impares, "%d\n", i);
        }
    }
    fclose(pares);
    fclose(impares);
    return 0;
}*/

/*Faça um programa em C para criar dinamicamente memória
para int, char e float. Teste o programa recebendo e imprimindo
valores para cada tipo*/

/*#include <stdio.h>
#include <stdlib.h>

int main() {

    int *p_int;
    char *p_char;
    float *p_float;

    p_int = (int*) malloc(sizeof(int));
    p_char = (char*) malloc(sizeof(char));
    p_float = (float*) malloc(sizeof(float));

    printf("Digite um inteiro: ");
    scanf("%d", p_int);

    printf("Digite um caractere: ");
    scanf(" %c", p_char);

    printf("Digite um real: ");
    scanf("%f", p_float);

    printf("\nValores digitados:\n");

    printf("Inteiro: %d\n", *p_int);
    printf("Caractere: %c\n", *p_char);
    printf("Real: %.2f\n", *p_float);

    free(p_int);
    free(p_char);
    free(p_float);

    return 0;
}*/

/*
Faça um programa que crie um vetor de tamanho 10 alocado
dinamicamente por ponteiros.


#include <stdio.h>
#include <stdlib.h>

int main() {

    int *vetor;
    int i;

    vetor = (int*) malloc(10 * sizeof(int));

    if(vetor == NULL) {
        printf("Erro ao alocar memoria!");
        return 1;
    }

    for(i = 0; i < 10; i++) {
        printf("Digite um numero: ");
        scanf("%d", &vetor[i]);
    }

    printf("\nValores do vetor:\n");

    for(i = 0; i < 10; i++) {
        printf("%d\n", vetor[i]);
    }

    free(vetor);

    return 0;
}*/

/*
Escreva um programa em C para alocar memória
dinamicamente para armazenar N números inteiros inseridos pelo
usuário e, em seguida, exiba a soma de todos os N números.

#include <stdio.h>
#include <stdlib.h>

int main() {

    int *vetor;
    int n, i, soma = 0;

    printf("Digite a quantidade de numeros: ");
    scanf("%d", &n);

    vetor = (int*) malloc(n * sizeof(int));

    if(vetor == NULL) {
        printf("Erro ao alocar memoria!");
        return 1;
    }

    for(i = 0; i < n; i++) {
        printf("Digite um numero: ");
        scanf("%d", &vetor[i]);

        soma += vetor[i];
    }

    printf("\nSoma dos numeros: %d", soma);

    free(vetor);

    return 0;
}*/

/*Declare uma struct para armazenar o nome, idade, código, sexo e
salário de um Funcionário. Construa uma função responsável por
declarar um Funcionário e por receber os dados deste Funcionário do
usuário. Escreva uma função para exibir os dados do Funcionário
declarado na função anterior. A função deve receber um parâmetro
do tipo Funcionário.
*/

/*#include <stdio.h>
#include <stdlib.h>

struct Funcionario {
    char nome[50];
    int idade;
    int codigo;
    char sexo;
    float salario;
};

struct Funcionario cadastrar(){
    struct Funcionario f;

    printf("Digite o nome do funcionario: ");
    scanf("%49s", f.nome);

    printf("Digite a idade do funcionario: ");
    scanf("%d", &f.idade);

    printf("Digite o codigo do funcionario: ");
    scanf("%d", &f.codigo);

    printf("Digite o sexo do funcionario (M/F): ");
    scanf(" %c", &f.sexo);

    printf("Digite o salario do funcionario: ");
    scanf("%f", &f.salario);

    return f;
}

void exibir(struct Funcionario f){
    printf("\nDados do funcionario:\n");
    printf("Nome: %s\n", f.nome);
    printf("Idade: %d\n", f.idade);
    printf("Codigo: %d\n", f.codigo);
    printf("Sexo: %c\n", f.sexo);
    printf("Salario: %.2f\n", f.salario);
}
 int main(){
    
    struct Funcionario Funcionario;
    Funcionario = cadastrar();

    exibir(Funcionario);
    return 0;
}*/

/*Defina uma struct que irá representar bandas de música. Essa
estrutura deve ter o nome da banda, que tipo de música ela toca e o
número de integrantes.
*/

/*#include <stdio.h>

struct Banda {
    char nome[50];
    char tipo_musica[50];
    int numero_integrantes;
};

int main(){
    struct Banda banda1;
    return 0;
}*/

/*Fazer um programa que utiliza um enum para descrever os meses do
ano.*/

/*#include <stdio.h>

enum Meses {
    JANEIRO,
    FEVEREIRO,
    MARCO,
    ABRIL,
    MAIO,
    JUNHO,
    JULHO,
    AGOSTO,
    SETEMBRO,
    OUTUBRO,
    NOVEMBRO,
    DEZEMBRO
};*/

/*Escreva um programa em C que leia as medidas dos lados de um
triângulo e escreva se ele é equilátero, isósceles ou escaleno. Utilize
enum para os tipos dos triângulos.
*/

/*#include <stdio.h>
#include <stdlib.h>

enum TipoTriangulo {
    EQUILATERO,
    ISOSCELES,
    ESCALENO
};

int main(){
    float lado1, lado2, lado3;
    enum TipoTriangulo tipo;

    printf("Digite o comprimento do primeiro lado: ");
    scanf("%f", &lado1);
    printf("Digite o comprimento do segundo lado: ");
    scanf("%f", &lado2);
    printf("Digite o comprimento do terceiro lado: ");
    scanf("%f", &lado3);

    if(lado1 == lado2 && lado2 == lado3) {
        tipo = EQUILATERO;
        printf("O triangulo é Equilátero.\n");
    } else if(lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
        tipo = ISOSCELES;
        printf("O triangulo é Isósceles.\n");
    } else {
        tipo = ESCALENO;
        printf("O triangulo é Escaleno.\n");
    }

    return 0;
}*/
    
